# Automation Maintenance Report

## Test

- Test:
- Spec:
- Environment:
- Build/Commit:

## Failure

```text
Paste failure here
```

## Classification

- Category:
- Sub-category:
- Confidence:

## Root Cause

Describe the most likely root cause and the evidence supporting it.

## Evidence

- Error:
- Screenshot:
- Trace:
- DOM:
- Related tests:
- Recent application changes:

## Proposed Change

Describe the smallest safe change.

### Before

```typescript
```

### After

```typescript
```

## Files Changed

- 

## Validation

- [ ] ESLint
- [ ] TypeScript
- [ ] Failed test
- [ ] Related tests
- [ ] Regression subset

## Risk

Low / Medium / High

## Recommendation

- [ ] Safe to create PR
- [ ] Create PR with human review
- [ ] Do not modify automation
- [ ] Investigate product defect
- [ ] Investigate environment
