export class ClaimPage {
  constructor(private page: Page) {}

  async saveAndClose() {
    await this.page.getByRole('button', {
      name: 'Save & Close'
    }).click();
  }
}
