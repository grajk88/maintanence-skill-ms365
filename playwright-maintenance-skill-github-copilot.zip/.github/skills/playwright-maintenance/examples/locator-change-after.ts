export class ClaimPage {
  constructor(private page: Page) {}

  async save() {
    await this.page.getByRole('button', {
      name: 'Save'
    }).click();
  }

  async close() {
    await this.page.getByRole('button', {
      name: 'Close'
    }).click();
  }

  async saveAndClose() {
    await this.save();
    await this.close();
  }
}
