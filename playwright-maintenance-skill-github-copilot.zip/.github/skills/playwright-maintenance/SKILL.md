---
name: playwright-maintenance
description: Diagnose and safely maintain Playwright TypeScript automation failures, especially UI locator and workflow changes in Dynamics 365. Use when a Playwright test fails, when reviewing a suspected automation maintenance issue, or when updating tests after an application UI or workflow change.
---

# Playwright Maintenance Skill

## Objective

Maintain existing Playwright TypeScript automation safely and minimally when application changes cause test failures.

Primary use case:
- Dynamics 365 UI automation
- Locator changes
- New or changed UI features
- Workflow changes
- Synchronisation issues
- Test-data/environment failures

Do not treat every failure as a locator problem.

## Maintenance workflow

Follow this sequence:

1. Detect the failure.
2. Collect evidence.
3. Classify the failure.
4. Determine root cause and confidence.
5. Decide whether automated remediation is appropriate.
6. Make the smallest safe change.
7. Validate the change.
8. Produce a maintenance report.
9. Recommend PR creation or human review.

## Evidence to inspect

When available, inspect:

- Test error and stack trace
- Screenshot
- Playwright trace
- Video
- DOM snapshot / HTML
- Test result JSON
- Current URL
- Browser and environment
- Git commit/build information
- Existing Page Object
- Existing fixtures and utilities
- Related tests
- Recent code changes

Never infer a UI change from the error message alone when stronger evidence is available.

## Failure classification

Classify failures into one primary category:

### Automation
- Locator changed
- Locator is ambiguous
- Synchronisation issue
- Assertion changed
- Page Object issue
- Framework issue
- Test-data issue

### Application
- New feature
- UI workflow changed
- Business behaviour changed
- Product defect

### Environment
- Authentication
- Network
- Service unavailable
- Configuration
- Dependency outage

### Unknown
Use when evidence is insufficient.

## Confidence policy

Use confidence levels:

### HIGH
Strong evidence supports the diagnosis and the proposed change is low risk.

Examples:
- Existing locator no longer exists.
- A new stable accessible name is clearly present.
- The same business action remains available.
- Related tests confirm the same UI behaviour.

### MEDIUM
Evidence suggests a likely fix but business intent is not fully established.

Create a proposed change and recommend human review.

### LOW
The failure may indicate a product/workflow change or insufficient evidence.

Do not modify production automation automatically.

## Locator maintenance rules

Preferred locator order:

1. getByRole()
2. getByLabel()
3. getByTestId()
4. getByText()
5. Stable CSS selector
6. XPath only as a last resort

Prefer semantic and user-facing locators.

Do not replace a locator with a brittle selector merely to make the test pass.

Do not introduce waitForTimeout() as a maintenance fix.

Use Playwright auto-waiting and web-first assertions.

## Important Dynamics 365 rule

Dynamics 365 can change UI structure, labels, command bars, controls and workflows.

Before replacing a locator, determine whether:

1. Only the locator changed, or
2. The business workflow changed.

Example:

Old:
"Save & Close"

New:
"Save"

Do not automatically assume that replacing the locator is correct. Determine whether "Save" still represents the same business action and whether "Close" is now a separate action.

## Page Object rules

Keep page-specific locators and interactions in Page Objects.

Do not place a one-off locator directly in a test if an appropriate Page Object exists.

Before creating a new Page Object:

- Search for an existing one.
- Reuse existing components.
- Follow existing naming conventions.
- Avoid duplicate abstractions.

## Safe remediation

Prefer the smallest change that restores the intended behaviour.

Do not:

- Rewrite unrelated tests.
- Reformat large files unnecessarily.
- Introduce new dependencies.
- Change test intent.
- Disable assertions.
- Increase timeouts without evidence.
- Add hard waits.
- Weaken locators simply to make a test green.

## Validation

After a code change:

1. Run ESLint.
2. Run TypeScript validation if available.
3. Run the failed test.
4. Run closely related tests.
5. Run a broader regression subset when appropriate.

A fix is not considered validated merely because the code compiles.

## PR safety

The Skill may prepare a proposed change or patch.

Automatic merge is not permitted.

If confidence is HIGH and validation succeeds, recommend creating a PR.

If confidence is MEDIUM or LOW, require human review.

## Maintenance report

Produce:

- Test name
- Failure
- Classification
- Root cause
- Evidence
- Confidence
- Proposed change
- Files changed
- Validation performed
- Risk
- Recommended action

## Example diagnosis

Failure:
getByRole('button', { name: 'Save & Close' }) not found.

Evidence:
- Trace shows the page loaded successfully.
- DOM contains a button named "Save".
- Screenshot shows Save and Close as separate commands.
- No application error occurred.

Classification:
Automation / UI workflow change

Confidence:
MEDIUM

Action:
Do not blindly replace the locator. Inspect the current workflow and update the Page Object to model Save and Close as separate actions if that matches the business behaviour.

## Final principle

The goal is not "make the test pass."

The goal is:

"Restore reliable automation while preserving the original business intent."
