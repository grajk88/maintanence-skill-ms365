# Refactoring Rules

## Do

- Make focused changes.
- Preserve test intent.
- Reuse existing abstractions.
- Remove obsolete locators.
- Improve brittle selectors when evidence supports it.
- Replace hard waits with deterministic synchronization.
- Keep Page Objects cohesive.
- Add assertions when a maintenance change exposes missing validation.

## Do not

- Rewrite the framework unnecessarily.
- Rename unrelated methods.
- Introduce dependencies without justification.
- Disable tests to remove failures.
- Comment out assertions.
- Increase global timeouts to hide failures.
- Replace stable locators with brittle selectors.
- Change business intent without evidence.

## Definition of a good maintenance fix

A good fix:

1. Explains the failure.
2. Addresses the root cause.
3. Minimises code changes.
4. Preserves business intent.
5. Passes validation.
6. Is easy for another engineer to review.
