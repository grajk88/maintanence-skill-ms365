# Framework Architecture

Assume a typical Playwright TypeScript framework:

```text
tests/
pages/
components/
fixtures/
utils/
test-data/
config/
playwright.config.ts
```

## Rules

### tests/
Tests describe business behaviour and should remain readable.

### pages/
Page-specific locators and actions belong here.

### components/
Reusable UI components belong here.

### fixtures/
Shared test setup, authentication and dependencies belong here.

### utils/
Reusable technical utilities belong here.

### test-data/
Externalise reusable test data where appropriate.

## Maintenance principle

Modify the lowest appropriate layer.

Example:

If a Dynamics button locator changed and the locator is defined in LoginPage.ts, update LoginPage.ts rather than every test using the login action.
