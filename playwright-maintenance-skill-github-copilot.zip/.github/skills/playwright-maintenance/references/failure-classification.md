# Failure Classification

Use this guide to classify Playwright failures.

| Category | Typical evidence | Default action |
|---|---|---|
| Locator change | Old locator absent, equivalent control present | Propose locator update |
| Synchronisation | Element appears after action/wait condition | Fix waiting strategy |
| Assertion change | UI behaviour changed but action remains valid | Review expected behaviour |
| New feature | New UI/workflow introduced | Assess test coverage |
| Product defect | Application behaviour is incorrect | Do not modify test to hide defect |
| Environment | Service/auth/network/configuration issue | Retry/investigate environment |
| Test data | Invalid or unavailable test data | Repair data/setup |
| Framework issue | Shared utility/fixture failure | Fix framework component |
| Unknown | Insufficient evidence | Human investigation |

## Locator change indicators

Strong indicators:

- Locator times out.
- DOM no longer contains the referenced element.
- A stable equivalent control exists.
- Screenshot confirms the same business action is available.

Weak indicator:

- The test failed once.

Do not change a locator based solely on a single transient failure.

## Product defect indicators

Examples:

- Save action is present but produces an incorrect result.
- Application displays an error.
- Business validation is incorrect.
- API response is incorrect.

Do not modify the automation merely to bypass the defect.

## Environment indicators

Examples:

- Authentication service unavailable.
- Dynamics environment is down.
- Network failure.
- Browser/service dependency unavailable.

Do not change application locators for environment failures.
