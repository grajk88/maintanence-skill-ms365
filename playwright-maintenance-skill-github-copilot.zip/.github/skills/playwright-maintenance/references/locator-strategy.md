# Locator Strategy

## Preferred order

1. getByRole()
2. getByLabel()
3. getByTestId()
4. getByText()
5. Stable CSS
6. XPath as last resort

## Good

```typescript
page.getByRole('button', { name: 'Save' })
page.getByLabel('Account Name')
page.getByTestId('claim-submit')
```

## Avoid

```typescript
page.locator('div:nth-child(4) > div > button')
page.locator('//div[3]/button[2]')
```

unless there is no reliable alternative.

## Maintenance rule

When an existing locator fails:

1. Inspect the current DOM.
2. Identify candidate controls.
3. Compare accessible name, role, label and test ID.
4. Determine whether the business action is unchanged.
5. Prefer the most stable semantic locator.
6. Validate the updated test.

Never add waitForTimeout() as a locator fix.
