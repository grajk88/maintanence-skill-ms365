# Project AI Instructions

This repository contains a Playwright TypeScript Quality Engineering framework.

## General rules

- Inspect existing framework patterns before creating new code.
- Prefer reuse over duplication.
- Preserve business intent.
- Do not introduce unnecessary dependencies.
- Use TypeScript.
- Use Playwright web-first assertions.
- Do not use arbitrary waitForTimeout() calls as a maintenance fix.
- Use existing Page Objects, fixtures, components and utilities.
- Treat ESLint and TypeScript validation as deterministic quality gates.

## AI maintenance

When a Playwright test fails, use the Playwright Maintenance Skill when relevant.

Do not assume every failure is a locator change.

Distinguish between:
- automation defect
- application/workflow change
- product defect
- environment issue
- test-data issue
- framework issue

For uncertain or potentially business-impacting changes, recommend human review.

## Dynamics 365

Dynamics 365 UI changes must be assessed for both locator changes and business workflow changes.

The objective is not simply to make a failed test green. The objective is to restore reliable automation while preserving business intent.
