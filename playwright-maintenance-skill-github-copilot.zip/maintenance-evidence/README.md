# Maintenance Evidence

This directory is an example location for CI-generated evidence.

Recommended structure per failed test:

```text
maintenance-evidence/
└── <test-id>/
    ├── error.txt
    ├── test-result.json
    ├── screenshot.png
    ├── trace.zip
    ├── video.webm
    └── dom.html
```

The maintenance Skill should use this evidence when available.

Do not commit large generated evidence files to the repository unless your project policy requires it.
