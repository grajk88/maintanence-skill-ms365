# Playwright Maintenance Skill for GitHub Copilot

This package provides a GitHub Copilot Agent Skill for maintaining Playwright TypeScript automation, with Dynamics 365 UI automation as a primary use case.

## Install

Copy the `.github` directory into the root of your Playwright repository.

The final structure should contain:

```text
your-repo/
└── .github/
    ├── copilot-instructions.md
    └── skills/
        └── playwright-maintenance/
            ├── SKILL.md
            ├── references/
            ├── examples/
            └── templates/
```

## How to use with GitHub Copilot

Use Copilot Agent mode in VS Code or another supported Copilot agent environment.

### Manual investigation

Provide the failure and ask:

```text
Use the playwright-maintenance skill.

Analyse this failed Dynamics 365 Playwright test.
Classify the failure, inspect the available evidence,
identify the root cause and propose the smallest safe fix.
Do not change code until the evidence supports the diagnosis.
```

### With failure artifacts

Place or attach the Playwright failure evidence:

```text
error.txt
test-result.json
screenshot.png
trace.zip
dom.html
```

Then ask Copilot to use those artifacts as evidence.

### Example

```text
Use the playwright-maintenance skill.

The Create New Claim test failed.

Review:
maintenance-evidence/create-new-claim/

Determine whether this is:
1. locator change
2. workflow/application change
3. product defect
4. environment issue
5. test-data issue
6. framework issue

If it is a safe automation maintenance change,
make the smallest change, run validation, and produce
a maintenance report.
```

## Recommended operating model

Do not give the AI unrestricted authority to change and merge automation.

Recommended flow:

```text
CI
 ↓
Playwright failure
 ↓
Evidence collection
 ↓
Copilot maintenance analysis
 ↓
Classification
 ↓
Confidence
 ↓
Proposed fix
 ↓
Validation
 ↓
Pull Request
 ↓
Human review
```

## Important

The Skill is the reasoning and workflow layer. It is not a replacement for Playwright, ESLint, TypeScript, CI/CD or test evidence.

For production use, connect the skill to your CI workflow so that failure artifacts are consistently collected and made available to the agent.
