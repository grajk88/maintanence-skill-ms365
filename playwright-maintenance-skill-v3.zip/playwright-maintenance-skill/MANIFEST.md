# Skill File Manifest

Version: 3.0.0

- SKILL.md
- README.md
- MANIFEST.md
- package.json
- tsconfig.json
- .gitignore
- maintenance/run-maintenance.ts
- maintenance/parsers/playwright-json-parser.ts
- maintenance/parsers/trace-parser.ts
- maintenance/analyser/classifier.ts
- maintenance/analyser/failure-analyser.ts
- maintenance/report/renderer.ts
- templates/maintenance-report.html
- schemas/report.schema.json
- prompts/failure-analysis.prompt.md
- src/report-model.ts
