import fs from 'node:fs';
import path from 'node:path';
import { DateTime } from 'luxon';
import type { MaintenanceReport } from '../../src/report-model.js';

const esc = (v: unknown) => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
const list = (a: string[]) => a.map(x => `<li>${esc(x)}</li>`).join('');

export function renderReport(report: MaintenanceReport, templatePath: string, outputPath: string) {
  let html = fs.readFileSync(templatePath, 'utf8');
  const rows = report.failures.map((f, i) => `<article class="failure-card"><h3>${i + 1}. ${esc(f.testName)}</h3><div class="meta"><b>File:</b> ${esc(f.testFile)} &nbsp; <b>Browser:</b> ${esc(f.browser)} &nbsp; <b>Category:</b> ${esc(f.category)} &nbsp; <b>Confidence:</b> ${esc(f.confidence)}</div><p><b>Summary:</b> ${esc(f.summary)}</p><p><b>Root Cause:</b> ${esc(f.rootCause)}</p><p><b>Verdict:</b> ${esc(f.verdict)}</p><h4>Evidence</h4><ul>${list(f.evidence)}</ul><h4>Timeline</h4><ul>${list(f.timeline)}</ul></article>`).join('');
  const generatedAt = DateTime.now().setZone('Europe/London').toFormat('dd LLL yyyy, HH:mm:ss');
  html = html
    .replaceAll('{{report.generatedAt}}', generatedAt)
    .replaceAll('{{summary.total}}', String(report.summary.total))
    .replaceAll('{{summary.passed}}', String(report.summary.passed))
    .replaceAll('{{summary.failed}}', String(report.summary.failed))
    .replaceAll('{{summary.flaky}}', String(report.summary.flaky))
    .replace('{{failures}}', rows || '<p>No failed or flaky tests were found.</p>');
  fs.mkdirSync(path.dirname(path.resolve(outputPath)), { recursive: true });
  fs.writeFileSync(outputPath, html, 'utf8');
}
