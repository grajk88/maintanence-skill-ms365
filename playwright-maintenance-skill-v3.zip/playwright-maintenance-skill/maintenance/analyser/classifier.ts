import type { Category, Confidence } from '../../src/report-model.js';

export function classify(error: string, traceLines: string[], retries: number, status: string): { category: Category; subcategory: string; confidence: Confidence } {
  const text = `${error}\n${traceLines.join('\n')}`.toLowerCase();

  if (status === 'flaky' || /passed.*failed|failed.*passed/.test(text) || (retries > 0 && /retry|retries/.test(text))) {
    return { category: 'FLAKY_TEST', subcategory: 'Retry/Intermittent', confidence: 'HIGH' };
  }
  if (/locator|strict mode violation|element.*not found|no element|selector/i.test(text)) {
    return { category: 'AUTOMATION_ISSUE', subcategory: 'Locator', confidence: 'HIGH' };
  }
  if (/timeout|timed out|waiting for/i.test(text)) {
    return { category: 'AUTOMATION_ISSUE', subcategory: 'Timeout', confidence: 'MEDIUM' };
  }
  if (/net::|econn|connection refused|dns|requestfailed|socket|502|503|504/i.test(text)) {
    return { category: 'ENVIRONMENT_ISSUE', subcategory: 'Network', confidence: 'HIGH' };
  }
  if (/401|403|authentication|unauthori[sz]ed|forbidden/i.test(text)) {
    return { category: 'ENVIRONMENT_ISSUE', subcategory: 'Authentication', confidence: 'MEDIUM' };
  }
  if (/test data|fixture data|invalid policy|invalid customer|data setup|record.*not found/i.test(text)) {
    return { category: 'TEST_DATA_ISSUE', subcategory: 'Test Data', confidence: 'MEDIUM' };
  }
  if (/expect\(|tohave|tobe|received.*expected|assertion/i.test(text)) {
    return { category: 'PRODUCT_BUG', subcategory: 'Assertion', confidence: 'LOW' };
  }
  if (/404|not found/i.test(text)) {
    return { category: 'PRODUCT_BUG', subcategory: 'Navigation/Endpoint', confidence: 'LOW' };
  }
  return { category: 'UNKNOWN', subcategory: 'Unknown', confidence: 'LOW' };
}
