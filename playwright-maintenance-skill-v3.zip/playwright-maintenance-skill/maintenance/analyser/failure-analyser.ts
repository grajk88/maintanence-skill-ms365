import type { Failure } from '../../src/report-model.js';
import type { JsonTestCase } from '../parsers/playwright-json-parser.js';
import type { TraceEvidence } from '../parsers/trace-parser.js';
import { classify } from './classifier.js';

const FALLBACK = 'Unable to determine root cause from supplied JSON and trace evidence.';

export function analyse(test: JsonTestCase, trace: TraceEvidence): Failure {
  const error = test.error ?? test.stackTrace ?? '';
  const c = classify(error, trace.lines, test.retries ?? 0, test.status);
  const evidence = [
    ...(error ? [`Playwright JSON error: ${error.slice(0, 1000)}`] : []),
    ...(trace.tracePath ? [`Trace supplied: ${trace.tracePath}`] : []),
    ...trace.lines.slice(0, 8).map(x => `Trace evidence: ${x}`)
  ];
  const hasDiagnosticEvidence = Boolean(error || trace.lines.length);
  const rootCause = hasDiagnosticEvidence && c.category !== 'UNKNOWN'
    ? `${c.subcategory} evidence is present in the supplied execution artifacts.`
    : FALLBACK;
  const category = hasDiagnosticEvidence ? c.category : 'UNKNOWN';
  const confidence = hasDiagnosticEvidence ? c.confidence : 'LOW';
  return {
    testName: test.testName,
    testFile: test.testFile,
    browser: test.browser,
    category,
    subcategory: hasDiagnosticEvidence ? c.subcategory : 'Unknown',
    summary: error ? error.split('\n')[0].slice(0, 300) : 'Failed test with no readable error message.',
    rootCause,
    confidence,
    evidence: evidence.length ? evidence : [FALLBACK],
    timeline: [
      `Test execution reported as ${test.status}.`,
      ...(test.retries ? [`${test.retries} retry/retries were recorded in the JSON results.`] : []),
      ...(trace.tracePath ? ['A trace artifact was supplied for analysis.'] : ['No matching trace artifact was identified.'])
    ],
    verdict: category === 'UNKNOWN' ? 'UNKNOWN — insufficient evidence.' : `${category} — ${hasDiagnosticEvidence ? c.subcategory : 'Unknown'}`,
    error: test.error,
    stackTrace: test.stackTrace,
    duration: test.duration,
    retries: test.retries
  };
}
