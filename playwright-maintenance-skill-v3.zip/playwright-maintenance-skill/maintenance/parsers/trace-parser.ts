import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import os from 'node:os';

export interface TraceEvidence {
  tracePath?: string;
  files: string[];
  lines: string[];
}

export function findTraceZips(root: string): string[] {
  if (!fs.existsSync(root)) return [];
  const found: string[] = [];
  const walk = (dir: string) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(p);
      else if (entry.name.toLowerCase() === 'trace.zip' || entry.name.toLowerCase().endsWith('-trace.zip')) found.push(p);
    }
  };
  walk(root);
  return found.sort();
}

export function inspectTrace(tracePath?: string): TraceEvidence {
  if (!tracePath || !fs.existsSync(tracePath)) return { files: [], lines: [] };
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'pw-trace-'));
  try {
    execFileSync('unzip', ['-qq', tracePath, '-d', tmp], { stdio: 'ignore' });
    const files: string[] = [];
    const lines: string[] = [];
    const walk = (dir: string) => {
      for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
        const p = path.join(dir, e.name);
        if (e.isDirectory()) walk(p);
        else {
          const relative = path.relative(tmp, p);
          files.push(relative);
          if (/\.(trace|network|json)$/i.test(e.name)) {
            try {
              const text = fs.readFileSync(p, 'utf8');
              for (const line of text.split(/\r?\n/)) {
                if (/error|exception|failed|timeout|timed out|requestfailed|404|401|403|500|502|503|504|net::|connection refused|dns/i.test(line)) {
                  lines.push(line.slice(0, 800));
                }
              }
            } catch { /* ignore binary/non-text content */ }
          }
        }
      }
    };
    walk(tmp);
    return { tracePath, files: files.slice(0, 200), lines: [...new Set(lines)].slice(0, 100) };
  } catch {
    return { tracePath, files: [], lines: ['Trace ZIP could not be inspected by the local archive reader.'] };
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
}
