import fs from 'node:fs';

export interface JsonAttachment {
  name?: string;
  path?: string;
  contentType?: string;
}

export interface JsonTestCase {
  testName: string;
  testFile: string;
  browser: string;
  status: string;
  duration?: number;
  error?: string;
  stackTrace?: string;
  retries?: number;
  attachments: JsonAttachment[];
}

function firstError(result: any): { message?: string; stack?: string } | undefined {
  const candidates = Array.isArray(result?.errors) ? result.errors : result?.error ? [result.error] : [];
  const first = candidates[0];
  if (!first) return undefined;
  if (typeof first === 'string') return { message: first };
  return { message: first.message ?? first.value, stack: first.stack };
}

function extractAttachments(results: any[]): JsonAttachment[] {
  return results.flatMap(r => Array.isArray(r?.attachments) ? r.attachments : []);
}

export function parsePlaywrightJson(file: string): JsonTestCase[] {
  const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
  const out: JsonTestCase[] = [];

  const walk = (suite: any, inheritedFile = '', inheritedTitle = '') => {
    for (const spec of suite.specs ?? []) {
      const title = [inheritedTitle, spec.title].filter(Boolean).join(' › ');
      for (const test of spec.tests ?? []) {
        const results = Array.isArray(test.results) ? test.results : [];
        const last = results.at(-1) ?? {};
        const status = test.status ?? last.status ?? 'unknown';
        const failed = status === 'failed' || status === 'timedOut' || results.some((r: any) => r.status === 'failed' || r.status === 'timedOut' || r.error);
        const flaky = status === 'flaky' || (results.length > 1 && results.some((r: any) => r.status === 'passed') && results.some((r: any) => r.status === 'failed' || r.status === 'timedOut'));
        if (!failed && !flaky) continue;

        const err = firstError(last) ?? firstError(test);
        const attachments = extractAttachments(results);
        out.push({
          testName: title || test.title || 'Unnamed test',
          testFile: spec.file ?? inheritedFile ?? 'Unknown',
          browser: test.projectName ?? test.project?.name ?? 'Unknown',
          status: flaky ? 'flaky' : 'failed',
          duration: last.duration,
          error: err?.message,
          stackTrace: err?.stack,
          retries: Math.max(0, results.length - 1),
          attachments
        });
      }
    }
    for (const child of suite.suites ?? []) {
      const childTitle = child.title ? [inheritedTitle, child.title].filter(Boolean).join(' › ') : inheritedTitle;
      walk(child, child.file ?? inheritedFile, childTitle);
    }
  };

  for (const suite of raw.suites ?? []) walk(suite, suite.file ?? '', suite.title ?? '');
  return out;
}

export function countSummary(file: string) {
  const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
  let total = 0, passed = 0, failed = 0, flaky = 0;
  const walk = (suite: any) => {
    for (const spec of suite.specs ?? []) for (const test of spec.tests ?? []) {
      total++;
      const results = Array.isArray(test.results) ? test.results : [];
      const status = test.status ?? results.at(-1)?.status;
      const isFlaky = status === 'flaky' || (results.length > 1 && results.some((r: any) => r.status === 'passed') && results.some((r: any) => r.status === 'failed' || r.status === 'timedOut'));
      if (isFlaky) flaky++;
      else if (status === 'passed') passed++;
      else if (status === 'failed' || status === 'timedOut') failed++;
    }
    for (const s of suite.suites ?? []) walk(s);
  };
  for (const s of raw.suites ?? []) walk(s);
  return { total, passed, failed, flaky };
}
