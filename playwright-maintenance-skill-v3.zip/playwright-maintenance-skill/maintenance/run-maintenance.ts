import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parsePlaywrightJson, countSummary } from './parsers/playwright-json-parser.js';
import { findTraceZips, inspectTrace } from './parsers/trace-parser.js';
import { analyse } from './analyser/failure-analyser.js';
import { renderReport } from './report/renderer.js';
import type { MaintenanceReport } from '../src/report-model.js';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));

function parseArgs(argv: string[]): Record<string, string> {
  const result: Record<string, string> = {};
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (!arg.startsWith('--')) continue;
    const key = arg.slice(2);
    const value = argv[i + 1];
    if (!value || value.startsWith('--')) throw new Error(`Missing value for --${key}`);
    result[key] = value;
    i++;
  }
  return result;
}

function findProjectRoot(startDir: string): string {
  let current = path.resolve(startDir);
  while (true) {
    if (fs.existsSync(path.join(current, 'package.json'))) return current;
    const parent = path.dirname(current);
    if (parent === current) break;
    current = parent;
  }
  return process.cwd();
}

function resolveFromRoot(root: string, value: string): string {
  return path.isAbsolute(value) ? value : path.resolve(root, value);
}

function attachmentCandidates(testAttachments: { path?: string; name?: string }[], root: string): string[] {
  return testAttachments
    .map(a => a.path)
    .filter((p): p is string => Boolean(p))
    .map(p => resolveFromRoot(root, p));
}

function selectTrace(
  test: ReturnType<typeof parsePlaywrightJson>[number],
  traces: string[],
  root: string
): string | undefined {
  const attachmentPaths = attachmentCandidates(test.attachments ?? [], root);
  const exact = attachmentPaths.find(p => traces.includes(p) || traces.some(t => path.resolve(t) === path.resolve(p)));
  if (exact) return exact;

  const named = traces.find(t => {
    const normal = path.normalize(t).toLowerCase();
    const testFile = path.basename(test.testFile).toLowerCase();
    const testName = test.testName.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    return normal.includes(testFile) || (testName.length > 8 && normal.includes(testName.slice(0, 24)));
  });
  return named;
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const rootInput = args['project-root'] ?? process.env.MAINTENANCE_PROJECT_ROOT;
  const projectRoot = path.resolve(rootInput ?? findProjectRoot(scriptDir));

  const resultsDir = resolveFromRoot(
    projectRoot,
    args['results-dir'] ?? process.env.PLAYWRIGHT_RESULTS_DIR ?? 'test-results'
  );
  const jsonPath = resolveFromRoot(
    projectRoot,
    args['json'] ?? process.env.PLAYWRIGHT_JSON ?? 'test-results/playwright-results.json'
  );
  const output = resolveFromRoot(
    projectRoot,
    args['output'] ?? process.env.MAINTENANCE_OUTPUT ?? 'maintenance-report.html'
  );
  const template = path.resolve(projectRoot, 'templates/maintenance-report.html');

  if (!fs.existsSync(projectRoot)) throw new Error(`Project root not found: ${projectRoot}`);
  if (!fs.existsSync(jsonPath)) throw new Error(`Playwright JSON results not found: ${jsonPath}`);
  if (!fs.existsSync(resultsDir)) throw new Error(`Test results directory not found: ${resultsDir}`);
  if (!fs.existsSync(template)) throw new Error(`Maintenance template not found: ${template}`);

  const tests = parsePlaywrightJson(jsonPath);
  const traces = findTraceZips(resultsDir);
  const failures = tests.map(test => {
    const tracePath = selectTrace(test, traces, projectRoot);
    return analyse(test, inspectTrace(tracePath));
  });

  const report: MaintenanceReport = {
    report: { generatedAt: '', timezone: 'Europe/London', templateVersion: '1.0' },
    summary: countSummary(jsonPath),
    failures
  };

  renderReport(report, template, output);
  console.log(`Project root: ${projectRoot}`);
  console.log(`JSON results: ${jsonPath}`);
  console.log(`Trace root: ${resultsDir}`);
  console.log(`Traces discovered: ${traces.length}`);
  console.log(`Failures analysed: ${failures.length}`);
  console.log(`Maintenance report: ${output}`);
}

try {
  main();
} catch (error) {
  console.error(error instanceof Error ? error.message : String(error));
  process.exit(2);
}
