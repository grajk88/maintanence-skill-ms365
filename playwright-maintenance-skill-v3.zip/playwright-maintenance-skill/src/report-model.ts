export type Category = 'PRODUCT_BUG' | 'AUTOMATION_ISSUE' | 'ENVIRONMENT_ISSUE' | 'TEST_DATA_ISSUE' | 'FLAKY_TEST' | 'UNKNOWN';
export type Confidence = 'HIGH' | 'MEDIUM' | 'LOW';

export interface Failure {
  testName: string;
  testFile: string;
  browser: string;
  category: Category;
  subcategory: string;
  summary: string;
  rootCause: string;
  confidence: Confidence;
  evidence: string[];
  timeline: string[];
  verdict: string;
  error?: string;
  stackTrace?: string;
  duration?: number;
  retries?: number;
}

export interface MaintenanceReport {
  report: {
    generatedAt: string;
    timezone: 'Europe/London';
    templateVersion: '1.0';
  };
  summary: {
    total: number;
    passed: number;
    failed: number;
    flaky: number;
  };
  failures: Failure[];
}
