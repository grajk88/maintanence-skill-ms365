# Playwright Maintenance Skill v3

## Purpose
Analyse Playwright execution JSON and trace artifacts from the **project root** and publish one consistent HTML failure-analysis report.

## Default project layout
```text
<project-root>/
├── test-results/
│   ├── playwright-results.json
│   └── .../trace.zip
├── maintenance/
│   └── ...skill files...
├── playwright.config.ts
└── package.json
```

## Input contract
- Primary input: `<project-root>/test-results/playwright-results.json`.
- Trace input: recursively discovered `trace.zip` / `*-trace.zip` beneath `<project-root>/test-results/`.
- Alternate paths are allowed only through explicit CLI options or environment variables.
- Analysis is limited to supplied Playwright JSON and trace evidence.

## Output contract
- Default output: `<project-root>/maintenance-report.html`.
- One report is generated per invocation.
- The HTML template is fixed at `templates/maintenance-report.html`.
- Template version: `1.0`.

## Project-root resolution
The analyser must not depend on the shell's current directory.
1. Use `--project-root` when supplied.
2. Otherwise use `MAINTENANCE_PROJECT_ROOT` when supplied.
3. Otherwise locate the nearest ancestor containing `package.json`, starting from the maintenance script directory.
4. Fall back to `process.cwd()` only when no project marker can be found.

## Optional CLI options
```text
--project-root <path>
--results-dir <path>
--json <path>
--output <path>
```

Relative paths are resolved against the project root.

## Strict boundaries
- Read-only analysis.
- No source-code edits.
- No auto-fixes or patches.
- No test execution by the analyser.
- No Git operations.
- No dependency/config/test-data changes.
- No conclusions unsupported by supplied evidence.
- Do not generate remediation instructions.
- Do not modify the fixed HTML template at runtime.

## Evidence rule
**NO EVIDENCE = NO CONCLUSION.**

When evidence is insufficient, use exactly:
`Unable to determine root cause from supplied JSON and trace evidence.`

## Categories
- PRODUCT_BUG
- AUTOMATION_ISSUE
- ENVIRONMENT_ISSUE
- TEST_DATA_ISSUE
- FLAKY_TEST
- UNKNOWN

## Confidence
- HIGH: direct, consistent evidence from the supplied artifacts.
- MEDIUM: relevant evidence exists but does not prove the conclusion completely.
- LOW: weak or incomplete evidence; use UNKNOWN when there is not enough evidence to classify.

## Branding
- Legal & General logo is fixed in the template.
- Brand palette is centrally defined in the template.
- The analyser must not choose colours or alter branding.
- Footer must contain:
  - `Report Generated: DD MMM YYYY, HH:mm:ss (Europe/London)`
  - `© Legal & General Institutional Retirement`

## Operational rule
The skill analyses only failed/flaky tests represented in the JSON. It does not run Playwright itself.
