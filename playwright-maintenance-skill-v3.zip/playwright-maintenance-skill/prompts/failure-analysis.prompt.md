# Failure Analysis Prompt Contract

Analyse only the supplied Playwright JSON result data and trace evidence.

## Rules
- Do not use external evidence.
- Do not inspect or infer from source code, Git, configuration, dependencies, or test data.
- Do not propose fixes or remediation.
- Do not generate HTML; return structured analysis for the fixed renderer.
- Every conclusion must be supported by evidence present in the supplied JSON or trace.
- If evidence is insufficient, use exactly:
  `Unable to determine root cause from supplied JSON and trace evidence.`

## Categories
PRODUCT_BUG, AUTOMATION_ISSUE, ENVIRONMENT_ISSUE, TEST_DATA_ISSUE, FLAKY_TEST, UNKNOWN.

## Confidence
HIGH = direct and consistent evidence.
MEDIUM = plausible but not fully conclusive evidence.
LOW = weak/incomplete evidence.
