# Playwright Maintenance Skill v3

A read-only failure-analysis utility for existing Playwright TypeScript projects.

## What it does
- Reads Playwright JSON results from the **project root**.
- Recursively discovers Playwright trace ZIP files under `test-results/`.
- Analyses failed/flaky tests only.
- Correlates a failure with its trace using JSON attachment paths where available, with a deterministic fallback only when necessary.
- Produces one fixed, branded `maintenance-report.html`.
- Never edits tests, source code, configuration, dependencies, or test data.

## Expected project layout
```text
my-playwright-project/
├── test-results/
│   ├── playwright-results.json
│   └── .../trace.zip
├── maintenance/
│   ├── run-maintenance.ts
│   ├── parsers/
│   ├── analyser/
│   └── report/
├── templates/
│   └── maintenance-report.html
├── schemas/
├── prompts/
├── playwright.config.ts
└── package.json
```

## Install into an existing framework
Copy these folders/files into your Playwright repository:
- `maintenance/`
- `templates/`
- `schemas/`
- `prompts/`
- `src/report-model.ts`

Merge the scripts/dependencies from this skill's `package.json` into your existing `package.json`. Do not replace an existing project package.json blindly.

## Playwright configuration
Use a JSON reporter and tracing, for example:
```ts
reporter: [
  ['list'],
  ['json', { outputFile: 'test-results/playwright-results.json' }]
],
use: {
  trace: 'on-first-retry'
}
```

If you want traces for every failed test, `retain-on-failure` is also supported by Playwright and can be used instead.

## Run
From anywhere inside the repository, the skill resolves the project root independently of the shell's current directory:
```bash
npm run maintenance
```

Default locations:
```text
Input JSON:  <project-root>/test-results/playwright-results.json
Traces:      <project-root>/test-results/**/trace.zip
Output HTML: <project-root>/maintenance-report.html
```

You can also explicitly set the root:
```bash
npm run maintenance -- --project-root .
```

Or use custom paths:
```bash
npm run maintenance -- --results-dir results --json results/playwright.json --output reports/maintenance.html
```

Environment variables are also supported:
```text
MAINTENANCE_PROJECT_ROOT
PLAYWRIGHT_RESULTS_DIR
PLAYWRIGHT_JSON
MAINTENANCE_OUTPUT
```

CLI arguments take precedence over environment variables.

## Run after tests
Recommended:
```bash
npm test
npm run maintenance
```

Or:
```bash
npm run test:analyse
```

The maintenance analyser does not execute tests; `test:analyse` is simply a convenience script that runs Playwright first and then invokes the analyser.

## Evidence policy
If JSON and trace evidence do not support a root-cause conclusion, the report uses:
`Unable to determine root cause from supplied JSON and trace evidence.`

The skill does not produce code fixes or remediation steps.
